#pragma once
DECLARE_LOG_CATEGORY_EXTERN(HaxeLog, Log, All);

extern "C" {
  HAXERUNTIME_API void check_hx_init();
}
