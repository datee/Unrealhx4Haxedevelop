namespace UIXEnums
{
	enum class UIXActionTriggerResult : uint8
	{
		Completed,
		OnError
	}
};