Milestone 1:

  * [ ] make hand-generated basic (basic types) externs to work with UE4
  * [ ] allow extension of hand-generated basic externs -> 
  * [ ] templated types (TArray, TMap, TSubclassOf) -> @:generic + onGenerate macro ?
  * [ ] UStructs
  * [ ] interfaces
  * [ ] garbage collection
    * see https://github.com/enlight/klawr/blob/525c8c011d4ce82aa48806098d97092c0ac18fdf/Engine/Plugins/Klawr/KlawrRuntimePlugin/Source/KlawrRuntimePlugin/Private/KlawrObjectReferencer.h


Milestone 2:

  * [ ] automated extern definitions
