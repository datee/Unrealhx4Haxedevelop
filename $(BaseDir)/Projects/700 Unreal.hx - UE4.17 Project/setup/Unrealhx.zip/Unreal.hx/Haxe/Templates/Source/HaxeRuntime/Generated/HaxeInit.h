#pragma once

extern "C" {
  HAXERUNTIME_API void check_hx_init();
}
